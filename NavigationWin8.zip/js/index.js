$(function () {
    App.init();
});
var App = {
    init: function () {
        this.navigation(), this.hyperlinks()
    },
    navigation: function () {
        $(".nav .mask").on("touchstart click", function (e) {
            e.preventDefault(), $(this).parent().toggleClass("active")
        })
    },
    hyperlinks: function () {
        $(".nav .nav-item").on("click", function (e) {
            e.preventDefault();
            var t = $(this).attr("href").replace("#", "");
            $(".html").removeClass("visible"), $(".html." + t).addClass("visible"), $(".nav").toggleClass("active"), App.title($(this).text())
        })
    }
};